# pravallika-agents: a Claude Code plugin marketplace

This folder is a **marketplace** (a catalogue of plugins) holding one plugin, **payflow-agents**:

| Inside the plugin | What it is |
| --- | --- |
| `agents/data-analyst.md` | Answers questions about PayFlow transfer data |
| `agents/confluence-reader.md` | Reads Confluence pages (needs the Atlassian MCP server added separately) |
| `.mcp.json` + `server/` | The payflow-data MCP server the data-analyst uses; starts automatically |

```
payflow-marketplace/
  .claude-plugin/marketplace.json       the catalogue
  plugins/payflow-agents/
    .claude-plugin/plugin.json          the plugin's name and version
    agents/                             the two agents
    .mcp.json                           registers the MCP server
    server/                             the MCP server and its data
```

## Install it yourself (to test)

```bash
claude plugin marketplace add C:\Users\DELL\Documents\Simple\payflow-marketplace
claude plugin install payflow-agents@pravallika-agents
claude plugin list
```

Then, in any folder:

```bash
claude --agent payflow-agents:data-analyst -p "How many transfers failed in March 2026?"
```

Or start `claude`, type `@` and pick **payflow-agents:data-analyst**. The first time, allow the payflow-data tools when asked.

## Give it to your team

1. Put this folder in a git repository (GitHub, GitLab or Bitbucket). It can be private.
2. Teammates run:
   ```bash
   claude plugin marketplace add <your-org>/<repo-name>      # GitHub shorthand, or the full git URL
   claude plugin install payflow-agents@pravallika-agents
   ```
3. To ship a change, edit the files, raise `version` in `plugins/payflow-agents/.claude-plugin/plugin.json`, and push.

Teammates need Python on their PATH as `python` (the MCP server uses only the standard library).

## Check before sharing

```bash
claude plugin validate .
```

The last line should read `Validation passed`.

## Tool names inside a plugin

MCP tools from a plugin get a prefix: `mcp__plugin_<plugin>_<server>__<tool>`, for example
`mcp__plugin_payflow-agents_payflow-data__transfer_summary`. Agents list these full names in their `tools:` line.
